function myfunction() {
var txt;
var Angka;
Angka 
Angka = prompt ("Masukkan Angka Baru: ");
if (Angka % 2 == 0) {
	alert(+ Angka + "genap")
	txt="<p style = 'color:red'>"+ Angka + " " + "genap";
}
else {
	alert(+ Angka + "ganjil")
	txt="<p style ='color':blue'>"+ Angka + " " + "ganjil";
}
	document.getElementById("riwayat").innerHTML = txt;
}

